// Function to handle form submission
function submitForm(event) {
    event.preventDefault();
    
    // Get form and status elements
    const form = document.getElementById('order-form');
    const submitButton = document.getElementById('submit-button');
    const statusDiv = document.getElementById('form-status');
    
    // Change button text and disable it
    submitButton.textContent = 'Processing...';
    submitButton.disabled = true;
    
    // Get form data
    const formData = new FormData(form);
    const formObject = {};
    
    // Convert FormData to object
    formData.forEach((value, key) => {
        formObject[key] = value;
    });
    
    // Add timestamp
    formObject.timestamp = new Date().toISOString();
    
    // Google Apps Script URL
    // Replace with your actual deployed Google Apps Script Web App URL
    const scriptURL = 'https://script.google.com/macros/s/AKfycbwR03iKyRxa0yraZ1HZPG8fbvGcEy9J8E4zYo_2EuoyxFMnf7ZLFkK7hIy5-_A15zy2WQ/exec';
    
    // Replace in script.js file
// Google Apps Script URL
const scriptURL = 'YOUR_GOOGLE_SCRIPT_URL';

// Send data to Google Sheets
fetch(scriptURL, {
    method: 'POST',
    body: JSON.stringify(formObject),
    headers: {
        'Content-Type': 'application/json'
    },
    mode: 'no-cors' // Add this line
})
.then(response => {
    // Since 'no-cors' will always return opaque response, we can't check response.ok
    // Instead, assume success unless there's an error
    statusDiv.innerHTML = `
        <div class="success-message">
            <h3>Order Submitted Successfully!</h3>
            <p>Thank you for your order. We will contact you shortly to confirm your delivery.</p>
        </div>
    `;
    statusDiv.style.display = 'block';
    
    // Reset form
    form.reset();
    
    // Scroll to the status message
    statusDiv.scrollIntoView({ behavior: 'smooth' });
})
.catch(error => {
    // Show error message
    statusDiv.innerHTML = `
        <div class="error-message">
            <h3>Submission Error</h3>
            <p>There was a problem submitting your order. Please try again or contact us directly.</p>
            <p>Error: ${error.message}</p>
        </div>
    `;
    statusDiv.style.display = 'block';
    console.error('Error:', error);
    })
    .finally(() => {
        // Re-enable the button
        submitButton.textContent = 'Submit Order';
        submitButton.disabled = false;
    });
    
    return false;
}

// Add styles for form status messages
document.addEventListener('DOMContentLoaded', function() {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
        .form-status {
            margin: 1.5rem 0;
            padding: 1.5rem;
            border-radius: 8px;
        }
        
        .success-message {
            background-color: rgba(76, 175, 80, 0.1);
            border: 1px solid #4CAF50;
            padding: 1rem;
            border-radius: 4px;
        }
        
        .success-message h3 {
            color: #4CAF50;
            margin-bottom: 0.5rem;
        }
        
        .error-message {
            background-color: rgba(244, 67, 54, 0.1);
            border: 1px solid #F44336;
            padding: 1rem;
            border-radius: 4px;
        }
        
        .error-message h3 {
            color: #F44336;
            margin-bottom: 0.5rem;
        }
    `;
    document.head.appendChild(styleElement);
});